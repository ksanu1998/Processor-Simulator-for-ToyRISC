package processor.pipeline;

import processor.Processor;
import generic.Simulator;
import generic.*;

public class InstructionFetch {
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	EX_IF_LatchType EX_IF_Latch;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch, EX_IF_LatchType eX_IF_Latch, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.IF_OF_Latch = iF_OF_Latch;
	}
	
	public void performIF()
	{
		if(IF_EnableLatch.isIF_enable())
		{
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
			/* Setting new PC value */
			if(IF_EnableLatch.stall_switch()) /* if Stall switch is disabled, PC and OF stages are stalled */
			{
				
				/* Fetching new instruction at currentPC */
				int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
				IF_OF_Latch.setInstruction(newInstruction); /* Passing instruction to IF-OF Latch */
				containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
				Simulator.increment_dynamic_instructions(); /* for stats */
				if(IF_EnableLatch.wrong_branch_taken()) /* if the instructions in IF and OF are in wrong branch, convert them to nop in the next cycle */
				{
					IF_OF_Latch.set_is_nop(true);
					OF_EX_Latch.setoptype(Instruction.OperationType.valueOf("nop"));
					containingProcessor.getRegisterFile().setProgramCounter(IF_EnableLatch.get_correct_pc());
					IF_EnableLatch.set_wrong_branch_taken(false);
				}
			}
			/* for verification and visualization purpose */
			/*
			System.out.println("IF -> PC -> "+currentPC);
			System.out.println("************************");
			*/
			
		}
		IF_OF_Latch.setOF_enable(true); /* Enabling OF stage */
	}

}
