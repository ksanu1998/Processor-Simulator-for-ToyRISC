package generic;

import java.io.*;
import generic.Operand.*;
import generic.ParsedProgram.*;
import generic.Instruction.*;
import java.math.BigInteger;

	
public class Simulator {
		
	static FileInputStream inputcodeStream = null;

	/* method to find 2's complement of a binary string */
	static String twosComplement(String bin) 
	{
        String twos = "", ones = "";

        for (int i = 0; i < bin.length(); i++) 
        {
            ones += flip(bin.charAt(i));
        }
        int number0 = new BigInteger(ones,2).intValue();
        StringBuilder builder = new StringBuilder(ones);
        boolean b = false;
        for (int i = ones.length()-1; i>0; i--) 
        {
            if (ones.charAt(i) == '1') 
            {
                builder.setCharAt(i, '0');
            } 
            else 
            {
                builder.setCharAt(i, '1');
                b = true;
                break;
            }
        }
        if (!b)
        {
            builder.append("1", 0, 7);
        }
        twos = builder.toString();
        return twos;
    }

    /* method to flip 0s and 1s in a string */
    static char flip(char c) 
    {
        return (c == '0') ? '1' : '0';
    }

	/* method to construct instructions of R3 type */
	public static int construct_instruction_r3(Instruction newInstruction)
	{
		/* creating strings to store opcode, rs1, rs2, rd */
		String opcode=null;
		String rs1 = String.format("%5s",Integer.toBinaryString(newInstruction.getSourceOperand1().getValue())).replace(" ","0");
		String rs2 = String.format("%5s",Integer.toBinaryString(newInstruction.getSourceOperand2().getValue())).replace(" ","0");
		String rd = String.format("%5s",Integer.toBinaryString(newInstruction.getDestinationOperand().getValue())).replace(" ","0");
		String unused = "000000000000";
		/* fetching the opcode of instruction */
		switch(newInstruction.getOperationType())
		{
			case add:
			{
				opcode="00000";
				break;
			}
			case sub:
			{
				opcode="00010";
				break;
			}
			case mul:
			{
				opcode="00100";
				break;
			}
			case div:
			{
				opcode="00110";
				break;
			}
			case and:
			{
				opcode="01000";
				break;
			}
			case or:
			{
				opcode="01010";
				break;
			}
			case xor:
			{
				opcode="01100";
				break;
			}
			case slt:
			{
				opcode="01110";
				break;
			}
			case sll:
			{
				opcode="10000";
				break;
			}
			case srl:
			{
				opcode="10010";
				break;
			}
			case sra:
			{
				opcode="10100";
				break;
			}
		}
		/* creating string of instruction in binary */
		String binary_instruction=opcode+rs1+rs2+rd+unused;
		/* converting binary string into integer */
		int instruction_int = new BigInteger(binary_instruction,2).intValue();
		/* checking the hexadecimal value of instruction integer (for verification purpose only) */
		/* String hex = String.format("%8s",Integer.toHexString(instruction_int)).replace(" ","0");
		System.out.println(hex); */
		/* Printing the integer instruction (for verification purpose only) */
		/* System.out.println(instruction_int); */
		return (instruction_int);
	}
	
	/* method to construct non-conditional instructions of R2I type */
	public static int construct_instruction_r2i(Instruction newInstruction)
	{
		/* creating strings to store opcode, rs1, rd, imm */
		String opcode = null;
		String rs1 = String.format("%5s",Integer.toBinaryString(newInstruction.getSourceOperand1().getValue())).replace(" ","0");
		String rd = null;
		String imm = null;

		/* checking the operand type of immediate which is stored in sourceOperand2 and fetching its value in binary */
		if(newInstruction.getSourceOperand2().getOperandType()==OperandType.valueOf("Label"))
		{
			if(ParsedProgram.symtab.get(String.valueOf(newInstruction.getSourceOperand2().getLabelValue()))>=0)
			{
				imm = String.format("%17s",Integer.toBinaryString(ParsedProgram.symtab.get(String.valueOf(newInstruction.getSourceOperand2().getLabelValue())))).replace(" ","0");
			}
			else
			{
				/* as immediate is negative, we find 2's complement of negative of immediate, which gives us the required value of the immediate in binary */
				imm = twosComplement(String.format("%17s",Integer.toBinaryString(-ParsedProgram.symtab.get(String.valueOf(newInstruction.getSourceOperand2().getLabelValue())))).replace(" ","0"));	
			}
		}	
		else
		{
			if(newInstruction.getSourceOperand2().getValue()>=0)
			{
				imm = String.format("%17s",Integer.toBinaryString(newInstruction.getSourceOperand2().getValue())).replace(" ","0");
			}
			else
			{
				/* as immediate is negative, we find 2's complement of negative of immediate, which gives us the required value of the immediate in binary */
				imm = twosComplement(String.format("%17s",Integer.toBinaryString(-newInstruction.getSourceOperand2().getValue())).replace(" ","0"));	
			}
		}
		rd = String.format("%5s",Integer.toBinaryString(newInstruction.getDestinationOperand().getValue())).replace(" ","0");
		/* fetching the opcode of instruction */
		switch(newInstruction.getOperationType())
		{
			case addi:
			{
				opcode="00001";
				break;
			}
			case subi:
			{
				opcode="00011";
				break;
			}
			case muli:
			{
				opcode="00101";
				break;
			}
			case divi:
			{
				opcode="00111";
				break;
			}
			case andi:
			{
				opcode="01001";
				break;
			}
			case ori:
			{
				opcode="01011";
				break;
			}
			case xori:
			{
				opcode="01101";
				break;
			}
			case slti:
			{
				opcode="01111";
				break;
			}
			case slli:
			{
				opcode="10001";
				break;
			}
			case srli:
			{
				opcode="10011";
				break;
			}
			case srai:
			{
				opcode="10101";
				break;
			}
			case load :
			{
				opcode="10110";
				break;
			}
			case store :
			{
				opcode="10111";
				break;
			}
		}
		/* creating string of instruction in binary */
		String binary_instruction=opcode+rs1+rd+imm;
		/* converting binary string into integer */
		int instruction_int = new BigInteger(binary_instruction,2).intValue();
		/* checking the hexadecimal value of instruction integer (for verification purpose only) */
		/* String hex = String.format("%8s",Integer.toHexString(instruction_int)).replace(" ","0");
		System.out.println(hex); */
		/* Printing the integer instruction (for verification purpose only) */
		/* System.out.println(instruction_int); */
		return(instruction_int);
	}

	/* method to construct conditional instructions of R2I type */
	public static int conditional_branch_instruction_r2i(Instruction newInstruction, int pc)
	{
		/* creating strings to store opcode, rs1, rd, imm */
		String opcode=null;
		String rs1 = String.format("%5s",Integer.toBinaryString(newInstruction.getSourceOperand1().getValue())).replace(" ","0");
		String rd = String.format("%5s",Integer.toBinaryString(newInstruction.getSourceOperand2().getValue())).replace(" ","0");
		String imm = null;

		/* checking the operand type of immediate which is stored in destinationOperand and fetching its value in binary */
		if(newInstruction.getDestinationOperand().getOperandType()==OperandType.valueOf("Label"))
		{
			/* setting relative address for branch */
			int displacement = ParsedProgram.symtab.get(String.valueOf(newInstruction.getDestinationOperand().getLabelValue()))-pc;
			if(displacement>=0)
			{
				imm = String.format("%17s",Integer.toBinaryString(ParsedProgram.symtab.get(String.valueOf(newInstruction.getDestinationOperand().getLabelValue()))-pc)).replace(" ","0");
			}
			else
			{
				/* as displacement is negative, we find 2's complement of negative of displacement, which gives us the required value of realative address */
				imm = twosComplement(String.format("%17s",Integer.toBinaryString(-ParsedProgram.symtab.get(String.valueOf(newInstruction.getDestinationOperand().getLabelValue()))+pc)).replace(" ","0"));	
			}
		}
		else
		{
			if(newInstruction.getDestinationOperand().getValue()>=0)
			{
				imm = String.format("%17s",Integer.toBinaryString(newInstruction.getDestinationOperand().getValue())).replace(" ","0");
			}
			else
			{
				/* as immediate is negative, we find 2's complement of negative of immediate, which gives us the required value of the immediate in binary */
				imm = twosComplement(String.format("%17s",Integer.toBinaryString(-newInstruction.getDestinationOperand().getValue())).replace(" ","0"));	
			}
		}
		
		/* fetching opcode of the instruction*/
		switch(newInstruction.getOperationType())
		{
			case beq : 
			{
				opcode="11001";
				break;
			}
			case bne :
			{
				opcode="11010";
				break;
			} 
			case blt : 
			{
				opcode="11011";
				break;
			}
			case bgt :
			{
				opcode="11100";
				break;
			}
		}
		/* creating string of instruction in binary */
		String binary_instruction=opcode+rs1+rd+imm;
		/* converting binary string into integer */
		int instruction_int = new BigInteger(binary_instruction,2).intValue();
		/* checking the hexadecimal value of instruction integer (for verification purpose only) */
		/* String hex = String.format("%8s",Integer.toHexString(instruction_int)).replace(" ","0");
		System.out.println(hex); */
		/* Printing the integer instruction (for verification purpose only) */
		/* System.out.println(instruction_int); */
		return (instruction_int);
	}

	/* method to construct jmp instruction of RI type */
	public static int construct_instruction_ri(Instruction newInstruction, int pc)
	{
		/* creating strings to store opcode, rd, imm */
		String opcode="11000";
		String rd=null;
		String imm=null;
		/* checking the operand type of immediate which is stored in destinationOperand and fetching its value in binary */
		if(newInstruction.getDestinationOperand().getOperandType()==OperandType.valueOf("Immediate"))
		{
			if(newInstruction.getDestinationOperand().getValue()>=0)
			{
				imm = String.format("%22s",Integer.toBinaryString(newInstruction.getDestinationOperand().getValue())).replace(" ","0");
			}
			else
			{
				/* as immediate is negative, we find 2's complement of negative of immediate, which gives us the required value of the immediate in binary */
				imm = twosComplement(String.format("%22s",Integer.toBinaryString(-newInstruction.getDestinationOperand().getValue())).replace(" ","0"));	
			}
			rd="00000";
		}
		else if(newInstruction.getDestinationOperand().getOperandType()==OperandType.valueOf("Label"))
		{
			/* setting relative address for branch */
			int displacement = ParsedProgram.symtab.get(String.valueOf(newInstruction.getDestinationOperand().getLabelValue()))-pc;
			if(displacement>=0)
			{
				imm = String.format("%22s",Integer.toBinaryString(ParsedProgram.symtab.get(String.valueOf(newInstruction.getDestinationOperand().getLabelValue()))-pc)).replace(" ","0");
			}
			else
			{
				/* as displacement is negative, we find 2's complement of negative of displacement, which gives us the required value of realative address */
				imm = twosComplement(String.format("%22s",Integer.toBinaryString(-ParsedProgram.symtab.get(String.valueOf(newInstruction.getDestinationOperand().getLabelValue()))+pc)).replace(" ","0"));
			}
			rd="00000";
		}
		else
		{
			rd = String.format("%5s",Integer.toBinaryString(newInstruction.getDestinationOperand().getValue())).replace(" ","0");
			imm="0000000000000000000000";
		}
		/* creating string of instruction in binary */
		String binary_instruction=opcode+rd+imm;
		/* converting binary string into integer */
		int instruction_int = new BigInteger(binary_instruction,2).intValue();
		/* checking the hexadecimal value of instruction integer (for verification purpose only) */
		/* String hex = String.format("%8s",Integer.toHexString(instruction_int)).replace(" ","0");
		System.out.println(hex); */
		/* Printing the integer instruction (for verification purpose only) */
		/* System.out.println(instruction_int); */
		return (instruction_int);
	}

	/* method to construct end instruction of RI type */
	public static int construct_end()
	{
		/* creating strings to store opcode */
		String opcode="11101";
		/* creating string of instruction in binary */
		String binary_instruction=opcode+"000000000000000000000000000";
		/* converting binary string into integer */
		int instruction_int = new BigInteger(binary_instruction,2).intValue();
		/* checking the hexadecimal value of instruction integer (for verification purpose only) */
		/* String hex = String.format("%8s",Integer.toHexString(instruction_int)).replace(" ","0");
		System.out.println(hex); */
		/* Printing the integer instruction (for verification purpose only) */
		/* System.out.println(instruction_int); */
		return (instruction_int);

	}

	/* method to parse assembly program file */
	public static void setupSimulation(String assemblyProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
	}
	
	/* method to assemble the parsed assembly program file and write into object program file*/
	public static void assemble(String objectProgramFile)
	{
		/* opening object program file in binary mode */
		FileOutputStream outputcodeStream = null;
		DataOutputStream dos = null;

			try
			{
				outputcodeStream = new FileOutputStream(objectProgramFile);
				dos = new DataOutputStream(outputcodeStream);
			}
			catch(Exception e)
			{
				Misc.printErrorAndExit("objectProgramFile not created: error\n"+e.toString());
			}
			
			/* writing firstCodeAddress, i.e; address of the first instruction into the header of object program file */
			try
			{
				/* fetching the firstCodeAddress */
				int firstCodeAddress=ParsedProgram.firstCodeAddress;
				/* writing the firstCodeAddress into object program file*/
				dos.writeInt(firstCodeAddress);
				/* checking the hexadecimal value of firstCodeAddress (for verification purpose only) */
				/* String hex = String.format("%8s",Integer.toHexString(firstCodeAddress)).replace(" ","0");
				System.out.println(hex); */
				/* Printing firstCodeAddress instruction (for verification purpose only) */
				/* System.out.println("First Code Address: "+firstCodeAddress);	*/
			}
			catch(Exception e)
			{
				Misc.printErrorAndExit("firstCodeAddress not found: error\n"+e.toString());
			}

			/* writing data into object program file */

			/* starting from 0 and looping until just before the firstCodeAddress */
			int firstCodeAddress=ParsedProgram.firstCodeAddress;
			for(int i=0;i<firstCodeAddress;i++)
			{
				/* writing the datu to object program file */
				try
				{
					/* checking the hexadecimal value of firstCodeAddress (for verification purpose only) */
					/* String hex = String.format("%8s",Integer.toHexString(ParsedProgram.data.get(i))).replace(" ","0");
					System.out.println(hex); */
					/* Printing the datum (for verification purpose only) */
					/* System.out.println("Data: "+ParsedProgram.data.get(i)); */
					dos.writeInt(ParsedProgram.data.get(i));
				}
				catch(Exception e)
				{
					Misc.printErrorAndExit("data not written properly: error\n"+e.toString());
				}
			}

			/* assembling instructions one-by-one and writing them as integers into object program file in binary mode */
			/* (integers will be converted to hexadecimal numbers while getting written into object program file) */

			/* starting with the instruction at mainFunctionAddress */
			/* pc keeps track of which instruction to be printed */
			int pc=ParsedProgram.mainFunctionAddress;
			
			for(int i=0;i<ParsedProgram.code.size();i++)
			{
				try
				{
					/* creating new object of Instruction class type and storing instruction in it */
					Instruction newInstruction = new Instruction();
					try
					{
						newInstruction=ParsedProgram.getInstructionAt(pc);
					}
					catch(Exception e)
					{
						Misc.printErrorAndExit("Next instruction not available: error\n"+e.toString());
					}
					
					/* checking the type of the instruction */
					switch(newInstruction.getOperationType())
					{
						/* instructions of R3 type */
						case add : 
						case sub : 
						case mul : 
						case div : 
						case and : 
						case or  : 
						case xor : 
						case slt : 
						case sll : 
						case srl : 
						case sra :	
						{
							try
							{
								/* creating integer instruction from the given instruction by calling respective method defined earlier and writing into object program file */
								dos.writeInt(construct_instruction_r3(newInstruction));
								/* Printing the instruction in readable assembly format(for verification purpose only) */
								/* System.out.println(newInstruction.toString()); */
							}
							catch(Exception e)
							{
								Misc.printErrorAndExit("R3 type instruction not assembled properly: error\n"+e.toString());
							}
							/* incrementing pc */
							pc=pc+1;
							break;
						}

						/* non-conditional instructions of R2I type */
						case addi :
						case subi :
						case muli :
						case divi : 
						case andi : 
						case ori : 
						case xori : 
						case slti : 
						case slli : 
						case srli : 
						case srai :
						case load :
						case store :
						{
							try
							{
								/* creating integer instruction from the given instruction by calling respective method defined earlier and writing into object program file */
								dos.writeInt(construct_instruction_r2i(newInstruction));
								/* Printing the instruction in readable assembly format(for verification purpose only) */
								/* System.out.println(newInstruction.toString()); */
							}
							catch(Exception e)
							{
								Misc.printErrorAndExit("non-conditional R2I type instruction not assembled properly: error\n"+e.toString());
							}
							/* incrementing pc */
							pc=pc+1;
							break;
						}

						/* conditional instructions of R2I type */
						case beq : 
						case bne : 
						case blt : 
						case bgt : 
						{
							try
							{
								/* creating integer instruction from the given instruction by calling respective method defined earlier and writing into object program file */
								dos.writeInt(conditional_branch_instruction_r2i(newInstruction, pc));
								/* Printing the instruction in readable assembly format(for verification purpose only) */
								/* System.out.println(newInstruction.toString()); */
							}
							catch(Exception e)
							{
								Misc.printErrorAndExit("conditional R2I type instruction not assembled properly: error\n"+e.toString());
							}
							/* incrementing pc */
							pc=pc+1;
							break;
						}

						/* jmp instruction */
						case jmp :
						{
							try
							{
								/* creating integer instruction from the given instruction by calling respective method defined earlier and writing into object program file */
								dos.writeInt(construct_instruction_ri(newInstruction, pc));
								/* Printing the instruction in readable assembly format(for verification purpose only) */
								/* System.out.println(newInstruction.toString()); */
							}
							catch(Exception e)
							{
								Misc.printErrorAndExit("jmp instruction not assembled properly: error\n"+e.toString());
							}
							/* incrementing pc */
							pc=pc+1;
							break;
						}

						/* end instruction */
						case end :	
						{
							try
							{
								/* creating integer instruction from the given instruction by calling respective method defined earlier and writing into object program file */
								dos.writeInt(construct_end());
								/* Printing the instruction in readable assembly format(for verification purpose only) */
								/* System.out.println(newInstruction.toString()); */
							}
							catch(Exception e)
							{
								Misc.printErrorAndExit("end instruction not assembled properly: error\n"+e.toString());
							}
							/* incrementing pc*/
							pc=pc+1;
						}
					}
				}
				catch(Exception e)
				{
					Misc.printErrorAndExit("Instruction not assembled properly: error\n"+e.toString());
				}
			}
			/* closing object program object file in binary mode and closing output stream */
			try
			{
				dos.close();
			}
			catch(Exception e) 
			{
				Misc.printErrorAndExit("DataOutputStream not closed: error\n"+e.toString());
			}
			try
			{
				outputcodeStream.close();
			}
			catch(Exception e) 
			{
				Misc.printErrorAndExit("FileOutputStream not closed: error\n"+e.toString());
			}
	}
}
