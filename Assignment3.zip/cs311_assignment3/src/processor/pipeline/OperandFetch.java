package processor.pipeline;

import processor.Processor;
import generic.*;
import java.math.BigInteger;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}
	/* Method to find 2's complement of a binary string */
	public String twosComplement(String bin) 
	{
        String twos = "", ones = "";

        for (int i = 0; i < bin.length(); i++) 
        {
            ones += flip(bin.charAt(i));
        }
        int number0 = new BigInteger(ones,2).intValue();
        StringBuilder builder = new StringBuilder(ones);
        boolean b = false;
        for (int i = ones.length()-1; i>0; i--) 
        {
            if (ones.charAt(i) == '1') 
            {
                builder.setCharAt(i, '0');
            } 
            else 
            {
                builder.setCharAt(i, '1');
                b = true;
                break;
            }
        }
        if (!b)
        {
            builder.append("1", 0, 7);
        }
        twos = builder.toString();
        return twos;
    }
    /* Method to flip 0s and 1s in a string */
    public char flip(char c) 
    {
        return (c == '0') ? '1' : '0';
    }

    /* Method to check opcode and return optype of an instruction */
	public Instruction.OperationType check_opcode(String binary_instruction)
	{
		String opcode = binary_instruction.substring(0,5);
		Instruction.OperationType optype = null;
		switch (opcode)
		{
			case "00000":
			{
				optype = Instruction.OperationType.valueOf("add");
				break;
			}
			case "00010":
			{
				optype = Instruction.OperationType.valueOf("sub");
				break;
			}
			case "00100":
			{
				optype = Instruction.OperationType.valueOf("mul");
				break;
			}
			case "00110":
			{
				optype = Instruction.OperationType.valueOf("div");
				break;
			}
			case "01000":
			{
				optype = Instruction.OperationType.valueOf("and");
				break;
			}
			case "01010":
			{
				optype = Instruction.OperationType.valueOf("or");
				break;
			}
			case "01100":
			{
				optype = Instruction.OperationType.valueOf("xor");
				break;
			}
			case "01110":
			{
				optype = Instruction.OperationType.valueOf("slt");
				break;
			}
			case "10000":
			{
				optype = Instruction.OperationType.valueOf("sll");
				break;
			}
			case "10010":
			{
				optype = Instruction.OperationType.valueOf("srl");
				break;
			}
			case "10100":
			{
				optype = Instruction.OperationType.valueOf("sra");
				break;
			}
			case "00001":
			{
				optype = Instruction.OperationType.valueOf("addi");
				break;
			}
			case "00011":
			{
				optype = Instruction.OperationType.valueOf("subi");
				break;
			}
			case "00101":
			{
				optype = Instruction.OperationType.valueOf("muli");
				break;
			}
			case "00111":
			{
				optype = Instruction.OperationType.valueOf("divi");
				break;
			}
			case "01001":
			{
				optype = Instruction.OperationType.valueOf("andi");
				break;
			}
			case "01011":
			{
				optype = Instruction.OperationType.valueOf("ori");
				break;
			}
			case "01101":
			{
				optype = Instruction.OperationType.valueOf("xori");
				break;
			}
			case "01111":
			{
				optype = Instruction.OperationType.valueOf("slti");
				break;
			}
			case "10001":
			{
				optype = Instruction.OperationType.valueOf("slli");
				break;
			}
			case "10011":
			{
				optype = Instruction.OperationType.valueOf("srli");
				break;
			}
			case "10101":
			{
				optype = Instruction.OperationType.valueOf("srai");
				break;
			}
			case "10110":
			{
				optype = Instruction.OperationType.valueOf("load");
				break;
			}
			case "10111":
			{
				optype = Instruction.OperationType.valueOf("store");
				break;
			}
			case "11001":
			{
				optype = Instruction.OperationType.valueOf("beq");
				break;
			}
			case "11010":
			{
				optype = Instruction.OperationType.valueOf("bne");
				break;
			}
			case "11011":
			{
				optype = Instruction.OperationType.valueOf("blt");
				break;
			}
			case "11100":
			{
				optype = Instruction.OperationType.valueOf("bgt");
				break;
			}
			case "11000":
			{
				optype = Instruction.OperationType.valueOf("jmp");
				break;
			}
			case "11101":
			{
				optype = Instruction.OperationType.valueOf("end");
				break;
			}
		}
		return optype;
	}

	/* Method to get register number */
	public int get_register_value(String binary_instruction, int start_index, int end_index)
	{
		String register = binary_instruction.substring(start_index,end_index+1);
		int register_value = new BigInteger(register,2).intValue();
		return register_value;	
	}  

	/* Method to get value of immediate */
	public int get_immediate_value(String binary_instruction, int start_index, int end_index)
	{
		String register = binary_instruction.substring(start_index,end_index+1);
		if(register.charAt(0)=='1')
		{
			int register_value = 0 - new BigInteger(twosComplement(register),2).intValue();
			return register_value;
		}
		int register_value = new BigInteger(register,2).intValue();
		return register_value;
		
	}  
	public void performOF()
	{
		if(IF_OF_Latch.isOF_enable())
		{
			int pc = containingProcessor.getRegisterFile().getProgramCounter();
			Instruction newInstruction = new Instruction();
			int instruction = IF_OF_Latch.getInstruction(); /* Fetching instruction from IF-OF Latch */
			String binary_instruction = null;

			/* Converting instruction into binary */
			if(instruction>=0)
			{
				binary_instruction = String.format("%32s",Integer.toBinaryString(instruction)).replace(" ","0");
			}
			else
			{
				binary_instruction = twosComplement(String.format("%32s",Integer.toBinaryString(-instruction)).replace(" ","0"));
			}
			int rs1 = 0;
			int rs2 = 0;
			int rd = 0;
			int imm = 0;

			/* Processing instruction by optype */
			switch(check_opcode(binary_instruction))
			{
						/* Instructions of R3 type */
						case add : 
						case sub : 
						case mul : 
						case div : 
						case and : 
						case or  : 
						case xor : 
						case slt : 
						case sll : 
						case srl : 
						case sra :
						{
							/* Fetching values stored in registers and immediate values */
							rs1 =containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 5, 9));
							rs2 = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 10, 14));
							rd = get_register_value(binary_instruction, 15, 19);

							/* Setting r3 type to true in OF_EX latch */
							OF_EX_Latch.set_is_r3();

							/* storing required values in OF_EX latch */
							OF_EX_Latch.setop1(rs1);
							OF_EX_Latch.setop2(rs2);
							OF_EX_Latch.setrd(rd);
							OF_EX_Latch.setoptype(check_opcode(binary_instruction));
							break;
						} 
						
						/* Non-conditional instructions of R2I type */
						case addi :
						case subi :
						case muli :
						case divi : 
						case andi : 
						case ori : 
						case xori : 
						case slti : 
						case slli : 
						case srli : 
						case srai :
						{
							/* Fetching values stored in registers and immediate values */
							rs1 = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 5, 9));
							rd = get_register_value(binary_instruction, 10, 14);
							imm = get_immediate_value(binary_instruction, 15, 31);

							/* setting non-conditional r2i type to true in OF_EX latch */
							OF_EX_Latch.set_is_r2i_non_conditional();

							/* storing required values in OF_EX latch */
							OF_EX_Latch.setop1(rs1);
							OF_EX_Latch.setrd(rd);
							OF_EX_Latch.setimm(imm);
							OF_EX_Latch.setoptype(check_opcode(binary_instruction));
							break;
						}

						/* Load / Store instructions */
						case load :
						{
							/* Fetching values stored in registers and immediate values */
							rs1 = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 5, 9));
							rd = get_register_value(binary_instruction, 10, 14);
							imm = get_immediate_value(binary_instruction, 15, 31);

							/* Setting load / store to true in OF_EX latch */
							OF_EX_Latch.set_is_load_store();

							/* Storing required values in OF_EX latch */
							OF_EX_Latch.setop1(rs1);
							OF_EX_Latch.setrd(rd);
							OF_EX_Latch.setimm(imm);
							OF_EX_Latch.setoptype(check_opcode(binary_instruction));
							break;
						}
						case store :
						{
							/* Fetching values stored in registers and immediate values */
							rs1 = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 5, 9));
							rd = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 10, 14));
							imm = get_immediate_value(binary_instruction, 15, 31);
							
							/* Setting load / store to true in OF_EX latch */
							OF_EX_Latch.set_is_load_store();

							/* Storing required values in OF_EX latch */
							OF_EX_Latch.setop1(rs1);
							OF_EX_Latch.setrd(rd);
							OF_EX_Latch.setimm(imm);
							OF_EX_Latch.setoptype(check_opcode(binary_instruction));
							break;
						}

						/* Conditional instructions of R2I type */
						case beq : 
						case bne : 
						case blt : 
						case bgt : 
						{
							/* Fetching values stored in registers and immediate values */
							rs1 = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 5, 9));
							rd = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 10, 14));
							imm = get_immediate_value(binary_instruction, 15, 31);

							/* Setting r2i conditional type to true in OF_EX latch */
							OF_EX_Latch.set_is_r2i_conditional();

							/* Storing required values in OF_EX latch */
							OF_EX_Latch.setop1(rs1);
							OF_EX_Latch.setop2(rd);
							OF_EX_Latch.setimm(imm);
							OF_EX_Latch.setpc(pc);
							OF_EX_Latch.setoptype(check_opcode(binary_instruction));
							OF_EX_Latch.setbranchtarget_conditional(pc + imm);
							break;
						}

						/* Jmp instruction */
						case jmp :
						{
							/* Fetching values stored in registers and immediate values */
							rd = containingProcessor.getRegisterFile().getValue(get_register_value(binary_instruction, 5, 9));
							imm = get_immediate_value(binary_instruction, 10, 31);

							/* Setting jmp to true in OF_EX latch */
							OF_EX_Latch.set_is_jmp();

							/* Storing required values in OF_EX latch */
							OF_EX_Latch.setop2(rd);
							OF_EX_Latch.setimm(imm);
							OF_EX_Latch.setpc(pc);
							OF_EX_Latch.setoptype(check_opcode(binary_instruction));
							OF_EX_Latch.setbranchtarget_jmp(rd + pc + imm);
							break;
						}

						/* End instruction */
						case end :
						{
							/* Setting setSimulationComplete to true -> Ends simulation */
							Simulator.setSimulationComplete(true);

							/* Updating Program Counter */
							int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
							containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
							break;
						}

			}
			/* Disabling OF stage */
			IF_OF_Latch.setOF_enable(false);
			/* Enabling EX stage */
			OF_EX_Latch.setEX_enable(true);
		}
	}

}
