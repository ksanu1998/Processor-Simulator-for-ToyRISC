package processor.pipeline;

import processor.Processor;
import generic.*;
import java.math.BigInteger;
public class Execute 
{
	IF_EnableLatchType IF_EnableLatch;
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performEX()
	{
		if(OF_EX_Latch.isEX_enable())
		{
			/* Fetching values from OF-EX Latch */
			Instruction.OperationType optype = OF_EX_Latch.optype;
			int op1 = OF_EX_Latch.getop1();
			int op2 = OF_EX_Latch.getop2();
			int imm = OF_EX_Latch.getimm();
			int rd = OF_EX_Latch.getrd();
			int branch_target_conditional = OF_EX_Latch.getbranchtarget_conditional();
			int branch_target_jmp = OF_EX_Latch.getbranchtarget_jmp();
			int alu_result = 0;

			/* Processing instruction by format and optype */
			/* ALU unit */
			if(OF_EX_Latch.is_r3 == true)
			{
				switch(optype)
				{
					case add : 
					{
						alu_result = op1 + op2;
						break;
					}
					case sub : 
					{
						alu_result = op1 - op2;
						break;
					}
					case mul : 
					{
						alu_result = op1 * op2;
						break;
					}
					case div : 
					{
						alu_result = op1 / op2;
						/* Storing remainder in %x31 */
						EX_MA_Latch.setx31_result(op1%op2);
						break;
					}
					case and : 
					{
						alu_result = op1 & op2;
						break;
					}
					case or  : 
					{
						alu_result = op1 | op2;
						break;
					}
					case xor : 
					{
						alu_result = op1 ^ op2;
						break;
					}
					case slt : 
					{
						if(op1<op2)
						{
							alu_result = 1;
						}
						else 
							alu_result = 0;
						break;
					}
					case sll : 
					{
						alu_result = op1<<op2;
						String op1_string = String.format("%32s",Integer.toBinaryString(op1)).replace(" ","0");
						String op1_shifted_out = op1_string.substring(0,op2);
						int shifted_out_bits = new BigInteger(op1_shifted_out,2).intValue();
						/* Storing shifted-out bits in %x31 */
						EX_MA_Latch.setx31_result(shifted_out_bits);
						break;
					}
					case srl : 
					{
						alu_result = op1>>>op2;
						String op1_string = String.format("%32s",Integer.toBinaryString(op1)).replace(" ","0");
						String op1_shifted_out = op1_string.substring(32-op2,32);
						int shifted_out_bits = new BigInteger(op1_shifted_out,2).intValue();
						/* Storing shifted-out bits in %x31 */
						EX_MA_Latch.setx31_result(shifted_out_bits);
						break;
					}
					case sra :
					{
						alu_result = op1>>op2;
						String op1_string = String.format("%32s",Integer.toBinaryString(op1)).replace(" ","0");
						String op1_shifted_out = op1_string.substring(32-op2,32);
						int shifted_out_bits = new BigInteger(op1_shifted_out,2).intValue();
						/* Storing shifted-out bits in %x31 */
						EX_MA_Latch.setx31_result(shifted_out_bits);
						break;
					}
				}
				EX_MA_Latch.setis_alu();
				EX_MA_Latch.setalu_result(alu_result);
				EX_MA_Latch.setdestination_register(rd);
				EX_MA_Latch.setMA_enable(true);
				OF_EX_Latch.is_r3 =false;
			}
			else if(OF_EX_Latch.is_r2i_non_conditional == true)
			{
				switch(optype)
				{
					case addi : 
					{
						alu_result = op1 + imm;
						break;
					}
					case subi : 
					{
						alu_result = op1 - imm;
						break;
					}
					case muli : 
					{
						alu_result = op1 * imm;
						break;
					}
					case divi : 
					{
						alu_result = op1 / imm;
						/* Storing remainder in %x31 */
						EX_MA_Latch.setx31_result(op1%imm);
						break;
					}
					case andi : 
					{
						alu_result = op1 & imm;
						break;
					}
					case ori  : 
					{
						alu_result = op1 | imm;
						break;
					}
					case xori : 
					{
						alu_result = op1 ^ imm;
						break;
					}
					case slti : 
					{
						if(op1<imm)
						{
							alu_result = 1;
						}
						else 
							alu_result = 0;
						break;
					}
					case slli : 
					{
						alu_result = op1<<imm;
						String op1_string = String.format("%32s",Integer.toBinaryString(op1)).replace(" ","0");
						String op1_shifted_out = op1_string.substring(0,imm);
						int shifted_out_bits = new BigInteger(op1_shifted_out,2).intValue();
						/* Storing shifted-out bits in %x31 */
						EX_MA_Latch.setx31_result(shifted_out_bits);
						break;
					}
					case srli : 
					{
						alu_result = op1>>>imm;
						String op1_string = String.format("%32s",Integer.toBinaryString(op1)).replace(" ","0");
						String op1_shifted_out = op1_string.substring(32-imm,32);
						int shifted_out_bits = new BigInteger(op1_shifted_out,2).intValue();
						/* Storing shifted-out bits in %x31 */
						EX_MA_Latch.setx31_result(shifted_out_bits);
						break;
					}
					case srai :
					{
						alu_result = op1>>imm;
						String op1_string = String.format("%32s",Integer.toBinaryString(op1)).replace(" ","0");
						String op1_shifted_out = op1_string.substring(32-imm,32);
						int shifted_out_bits = new BigInteger(op1_shifted_out,2).intValue();
						/* Storing shifted-out bits in %x31 */
						EX_MA_Latch.setx31_result(shifted_out_bits);
						break;
					}
				}
				EX_MA_Latch.setis_alu();
				EX_MA_Latch.setalu_result(alu_result);
				EX_MA_Latch.setdestination_register(rd);
				EX_MA_Latch.setMA_enable(true);	
				OF_EX_Latch.is_r2i_non_conditional = false;
			}
			else if(OF_EX_Latch.is_load_store == true)
			{
				switch(optype)
				{
					case load:
					{
						EX_MA_Latch.setis_load();
						int word_at = op1 + imm;
						EX_MA_Latch.setword_at(word_at);
						EX_MA_Latch.setdestination_register(rd);
						break;
					}
					case store:
					{
						EX_MA_Latch.setis_store();
						int word_at = rd + imm;
						EX_MA_Latch.setword_at(word_at);
						EX_MA_Latch.setsource_register(op1);
						break;
					}
				}
				EX_MA_Latch.setMA_enable(true);	
				OF_EX_Latch.is_load_store = false;
			}
			else if(OF_EX_Latch.is_r2i_conditional == true)
			{
				switch(optype)
				{
					case beq : 
					{
						if(op1 == op2)
						{
							containingProcessor.getRegisterFile().setProgramCounter(branch_target_conditional);
						}
						else
						{
							int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
							containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
						}
						break;
					}
					case bne : 
					{
						if(op1 != op2)
						{
							containingProcessor.getRegisterFile().setProgramCounter(branch_target_conditional);
						}
						else
						{
							int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
							containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
						}
						break;
					}
					case blt : 
					{
						if(op1 < op2)
						{
							containingProcessor.getRegisterFile().setProgramCounter(branch_target_conditional);
						}
						else
						{
							int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
							containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
						}
						break;
					}
					case bgt :
					{
						if(op1 > op2)
						{
							containingProcessor.getRegisterFile().setProgramCounter(branch_target_conditional);
						}
						else
						{
							int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
							containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
						}
						break;
					}
				}	
				/* Disabling MA stage for conditional instructions */
				EX_MA_Latch.setMA_enable(false);
				OF_EX_Latch.is_r2i_conditional = false;
			}
			else if(OF_EX_Latch.is_jmp == true)
			{
				containingProcessor.getRegisterFile().setProgramCounter(branch_target_jmp);
				/* Disabling MA stage for jmp instruction */
				EX_MA_Latch.setMA_enable(false);
				OF_EX_Latch.is_jmp = false;
			}
			/* Disabling EX stage */
			OF_EX_Latch.setEX_enable(false);
		}
	}
		
}
