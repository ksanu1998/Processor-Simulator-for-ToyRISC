package processor.pipeline;
import generic.*;

public class OF_EX_LatchType {
	
	boolean EX_enable;

	/* Booleans to indicate the instruction type */
	boolean is_r3 = false;
	boolean is_r2i_non_conditional = false;
	boolean is_load_store = false;
	boolean is_r2i_conditional = false;
	boolean is_jmp = false;
	boolean is_end = false;

	/* Variables required to store operands and immediate values */
	Instruction.OperationType optype = null;
	int pc = 0; 
	int op1 = 0;
	int op2 = 0;
	int imm = 0;
	int rd = 0;
	int branch_target_conditional = 0;
	int branch_target_jmp = 0;

	/* Methods to set and get various values, and to set instruction format type */
	public OF_EX_LatchType()
	{
		EX_enable = false;
	}

	public boolean isEX_enable() 
	{
		return EX_enable;
	}

	public void setEX_enable(boolean eX_enable) 
	{
		EX_enable = eX_enable;
	}

	public void setoptype(Instruction.OperationType given_optype) 
	{
		optype = given_optype;
	}

	public void set_is_r3() 
	{
		is_r3 = true;
	}

	public void set_is_r2i_non_conditional() 
	{
		is_r2i_non_conditional = true;
	}

	public void set_is_r2i_conditional() 
	{
		is_r2i_conditional = true;
	}

	public void set_is_load_store() 
	{
		is_load_store = true;
	}

	public void set_is_jmp() 
	{
		is_jmp = true;
	}

	public void set_is_end() 
	{
		is_end = true;
	}

	public void setpc(int given_pc) 
	{
		pc = given_pc;
	}
	
	public int getrd() 
	{
		return rd;
	}

	public void setrd(int given_rd) 
	{
		rd = given_rd;
	}

	public int getop1() 
	{
		return op1;
	}

	public void setop1(int given_op1) 
	{
		op1 = given_op1;
	}

	public int getop2() 
	{
		return op2;
	}

	public void setop2(int given_op2) 
	{
		op2 = given_op2;
	}

	public int getimm() 
	{
		return imm;
	}

	public void setimm(int given_imm) 
	{
		imm = given_imm;
	}
	public int getbranchtarget_conditional() 
	{
		return branch_target_conditional;
	}

	public void setbranchtarget_conditional(int branch_target) 
	{
		branch_target_conditional = branch_target;
	}
	public int getbranchtarget_jmp() 
	{
		return branch_target_jmp;
	}

	public void setbranchtarget_jmp(int branch_target) 
	{
		branch_target_jmp = branch_target;
	}

}
