package processor.pipeline;

public class MA_RW_LatchType {
	
	boolean RW_enable;
	
	/* Variables required to store operands and immediate values */
	int load_result = 0;
	int load_register = 0;
	int x31_result = 0;

	/* Methods to set and get various values */
	public MA_RW_LatchType()
	{
		RW_enable = false;
	}

	public boolean isRW_enable() 
	{
		return RW_enable;
	}

	public void setRW_enable(boolean rW_enable) 
	{
		RW_enable = rW_enable;
	}

	public void setload_result(int result)
	{
		load_result = result;
	}

	public int getload_result()
	{
		return load_result;
	}

	public void setx31_result(int x31)
	{
		x31_result = x31;
	}
	public int getx31_result()
	{
		return x31_result;
	}
	public void setload_register(int rd)
	{
		load_register = rd;
	}

	public int getload_register()
	{
		return load_register;
	}
}
