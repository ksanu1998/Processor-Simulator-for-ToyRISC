package processor.pipeline;

import generic.Simulator;
import processor.Processor;
import generic.*;
public class RegisterWrite 
{
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
		if(MA_RW_Latch.isRW_enable()==true)
		{
			/* Writing values into registers */
			containingProcessor.getRegisterFile().setValue(MA_RW_Latch.getload_register(),MA_RW_Latch.getload_result());
			containingProcessor.getRegisterFile().setValue(31,MA_RW_Latch.getx31_result());
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
			/* Setting new PC value */
			containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
			/* Disabling RW stage */
			MA_RW_Latch.setRW_enable(false);
		}
		Simulator.increment_dynamic_instructions(); /* for stats */
		/* Enabling IF stage */
		IF_EnableLatch.setIF_enable(true);
	}

}
