package processor.pipeline;

import processor.Processor;
import generic.*;
public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}
	
	public void performMA()
	{
		if(EX_MA_Latch.isMA_enable())
		{
			if(EX_MA_Latch.is_load)
			{
				/* Fetching load register and value , passing them to MA-RW Latch */
				int load_result = containingProcessor.getMainMemory().getWord(EX_MA_Latch.getword_at());
				MA_RW_Latch.setload_result(load_result);
				int x31_result = EX_MA_Latch.getx31_result();
				MA_RW_Latch.setx31_result(x31_result);
				int load_register = EX_MA_Latch.getdestination_register();
				MA_RW_Latch.setload_register(load_register);
				/* Enabling RW stage */
				MA_RW_Latch.setRW_enable(true);
				EX_MA_Latch.is_load = false;
			}
			else if(EX_MA_Latch.is_store)
			{
				/* Storing value into memory at given address */
				int getword_at = EX_MA_Latch.getword_at();
				int getsource_register = EX_MA_Latch.getsource_register();
				containingProcessor.getMainMemory().setWord(getword_at, getsource_register);
				int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
				/* Setting new PC value */
				containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
				/* Disabling RW stage */
				MA_RW_Latch.setRW_enable(false);
				EX_MA_Latch.is_store = false;
			}
			else if(EX_MA_Latch.is_alu)
			{
				/* Fetching alu result and load register, passing them to MA-RW Latch */
				int load_result = EX_MA_Latch.getalu_result();
				MA_RW_Latch.setload_result(load_result);
				int x31_result = EX_MA_Latch.getx31_result();
				MA_RW_Latch.setx31_result(x31_result);
				int load_register = EX_MA_Latch.getdestination_register();
				MA_RW_Latch.setload_register(load_register);
				/* Enabling RW stage */
				MA_RW_Latch.setRW_enable(true);
				EX_MA_Latch.is_alu = false;

			}
			/* Disabling MA stage */
			EX_MA_Latch.setMA_enable(false);
		}
	}

}
