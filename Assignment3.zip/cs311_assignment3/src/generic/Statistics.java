package generic;

import java.io.PrintWriter;

public class Statistics {
	
	static int numberOfInstructions;
	static int numberOfStaticInstructions;
	static long numberOfCycles;
	

	public static void printStatistics(String statFile)
	{
		try
		{
			PrintWriter writer = new PrintWriter(statFile);
			
			writer.println("Number of static instructions executed = " + numberOfStaticInstructions);
			writer.println("Number of dynamic instructions executed = " + numberOfInstructions);
			writer.println("Number of cycles taken = " + numberOfCycles);
			
			writer.close();
		}
		catch(Exception e)
		{
			Misc.printErrorAndExit(e.getMessage());
		}
	}
	
	public static void setNumberOfInstructions(int numberOfInstructions) {
		Statistics.numberOfInstructions = numberOfInstructions;
	}
	public static void setNumberOfStaticInstructions(int numberOfInstructions) {
		Statistics.numberOfStaticInstructions = numberOfInstructions;
	}
	public static void setNumberOfCycles(long numberOfCycles) {
		Statistics.numberOfCycles = numberOfCycles;
	}
}
