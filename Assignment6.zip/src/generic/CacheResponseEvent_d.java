package generic;

public class CacheResponseEvent_d extends Event {

	int value;
	
	public CacheResponseEvent_d(long eventTime, Element requestingElement, Element processingElement, int value) {
		super(eventTime, EventType.CacheResponse_d, requestingElement, processingElement);
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
